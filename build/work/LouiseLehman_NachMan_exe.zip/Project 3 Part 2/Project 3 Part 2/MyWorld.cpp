#include "MyWorld.h"
#include <iostream>
using namespace std;

GameStatus MyWorld::RunLevel()
{
	NachMan* NMptr = GetNachMan();
	Maze* Mptr = GetMaze();

	NMptr->changeNMstate(false);
	NMptr->SetX(Mptr->GetNachManStartX());
	NMptr->SetY(Mptr->GetNachManStartY());
	NMptr->changedir(NONE);

	for (int i = 0; i < 4; i++)
	{
		Monster* Monptr = GetMonster(i);
		Monptr->changeMstate(NORMAL);
		Monptr->SetX(Mptr->GetMonsterStartX());
		Monptr->SetY(Mptr->GetMonsterStartY());
	}

	DisplayScreen(true);

	int lives = NMptr->GetNumLivesLeft();

	while (!NMptr->NMstate() && Mptr->GetRemainingFood() > 0)
	{
		NMptr->DoSomething();

		if (!NMptr->NMstate())
		{
			for(int i = 0; i < 4; i++)
			{
				Monster* Monptr = GetMonster(i);
				Monptr->DoSomething();
			}
		}

		DisplayScreen(false);
	}

	if (Mptr->GetRemainingFood() == 0)
	{
		return FINISHED_LEVEL;
	}
	return PLAYER_DIED;
}
