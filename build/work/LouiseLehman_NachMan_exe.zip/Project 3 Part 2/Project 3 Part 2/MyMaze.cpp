#include "MyMaze.h"

MyMaze::~MyMaze()
{}

bool MyMaze::LoadMaze(const std::string &sMazeFile)
{
	Maze::LoadMaze(sMazeFile);
	determineDistances();
	return GetNachManStartX() != -1 && GetMonsterStartX() != -1;
}

bool MyMaze::GetNextCoordinate(int nCurX, int nCurY, int &nNextX, int &nNextY)
{
	if (nCurX == GetMonsterStartX()
		&& nCurY == GetMonsterStartY())
		return false;

	if (distances[nCurY+1][nCurX] < distances[nCurY][nCurX])
	{
		nNextY = nCurY+1;
	}
	else if (distances[nCurY-1][nCurX] < distances[nCurY][nCurX])
	{
		nNextY = nCurY-1;
	}
	else if (distances[nCurY][nCurX-1] < distances[nCurY][nCurX])
	{
		nNextX = nCurX-1;
	}
	else if (distances[nCurY][nCurX+1] < distances[nCurY][nCurX])
	{
		nNextX = nCurX+1;
	}

	return true;
}

void MyMaze::determineDistances ()
{
	for (int i = 0; i < MAZE_HEIGHT; i++)
	{
		for (int j = 0; j < MAZE_WIDTH; j++)
			distances[i][j] = 99;
	}
	distances[GetMonsterStartY()][GetMonsterStartX()] = 0;
	stack<Coord> coordstk;
	coordstk.push(Coord(GetMonsterStartY(), GetMonsterStartX()));
	while (!coordstk.empty())
	{
		Coord co = coordstk.top();
		coordstk.pop();
		int m = 99;

		if (GetGridContents(co.x(), co.y()+1) != WALL && distances[co.y()+1][co.x()] < m)
			m = distances[co.y()+1][co.x()];

		if (GetGridContents(co.x(), co.y()-1) != WALL && distances[co.y()-1][co.x()] < m)
			m = distances[co.y()-1][co.x()];
		
		if (GetGridContents(co.x()-1, co.y()) != WALL && distances[co.y()][co.x()-1] < m)
			m = distances[co.y()][co.x()-1];

		if (GetGridContents(co.x()+1, co.y()) != WALL && distances[co.y()][co.x()+1] < m)
			m = distances[co.y()][co.x()+1];

		if (distances[co.y()][co.x()] > m+1)
			distances[co.y()][co.x()] = m+1;

		int v = distances[co.y()][co.x()];
		
		if (GetGridContents(co.x()-1, co.y()) != WALL && distances[co.y()][co.x()-1] > v+1)
		{
			distances[co.y()][co.x()-1] = v+1;
			coordstk.push(Coord(co.y(), co.x()-1));
		}

		if (GetGridContents(co.x(), co.y()+1) != WALL && distances[co.y()+1][co.x()] > v+1)
		{
			distances[co.y()+1][co.x()] = v+1;
			coordstk.push(Coord(co.y()+1, co.x()));
		}

		if (GetGridContents(co.x()+1, co.y()) != WALL && distances[co.y()][co.x()+1] > v+1)
		{
			distances[co.y()][co.x()+1] = v+1;
			coordstk.push(Coord(co.y(), co.x()+1));
		}

		if (GetGridContents(co.x(), co.y()-1) != WALL && distances[co.y()-1][co.x()] > v+1)
		{
			distances[co.y()-1][co.x()] = v+1;
			coordstk.push(Coord(co.y()-1, co.x()));
		}
	}
}