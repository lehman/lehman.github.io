#ifndef _MYMAZE_H_
#define _MYMAZE_H_

#include "Maze.h"
#include <stack>

class MyMaze: public Maze
{
 public:
	MyMaze(GraphManager* gm)
		: Maze(gm)
	{}
	 ~MyMaze();
	 virtual bool LoadMaze(const std::string &sMazeFile);
	 virtual bool GetNextCoordinate(int nCurX, int nCurY, int &nNextX, int &nNextY);

private:
	Monster* mptr;
	int distances[MAZE_HEIGHT][MAZE_WIDTH];

	class Coord
	{
	public:
		Coord(int yy, int xx) : m_x(xx), m_y(yy) {}
		int x() const { return m_x; }
		int y() const { return m_y; }
	private:
		int m_x;
		int m_y;
	};
	void determineDistances ();
};

#endif //  _MYMAZE_H_
