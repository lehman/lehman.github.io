#include "Actor.h"
#include "UserInterface.h"
#include "GraphManager.h"
#include "BGIgraphics.h"
#include "World.h"
#include <iostream>
using namespace std;

// Actor class functions
Actor::Actor(int y, int x, colors color, int id, World* wptr)
	: mx(x), my(y), mcolor(color), mid(id), dir(NONE)
{
	mWptr = wptr;
}

Actor::~Actor()
{}

int Actor::GetX() const
{ return mx; }

int Actor::GetY() const
{ return my; }

void Actor::SetX(int newXCoord)
{ mx = newXCoord; }

void Actor::SetY(int newYCoord)
{ my = newYCoord; }

colors Actor::GetDisplayColor() const
{ return mcolor; }

void Actor::ChangeColor(colors c)
{ mcolor = c; }

int Actor::getMyID() const
{ return mid; }

Direction Actor::direc() const
{ return dir; }

void Actor::changedir(Direction d)
{ dir = d; }

World* Actor::Worldptr() const
{ return mWptr; }

/////////////////////////////////////
// NachMan class functions
/////////////////////////////////////

NachMan::NachMan(World* wptr, int y, int x)
	: Actor(y, x, YELLOW, ITEM_NACHMAN, wptr),
		mscore(0), mlives(3), mstate(false)
{}

NachMan::~NachMan()
{}

int NachMan::GetNumLivesLeft() const
{ return mlives; }

void NachMan::DecrementNumLives()
{
	mlives--;
	if (mlives < 0)
		mstate = true;	// dead
}

int NachMan::GetScore() const
{ return mscore; }

void NachMan::ChangeScore(int s)
{
	mscore += s;
}

bool NachMan::NMstate() const
{
	return mstate;	// true if dead
}

void NachMan::changeNMstate(bool st)
{
	mstate = st;
}

void NachMan::DoSomething()
{
	char ch;
	int newx = GetX();
	int newy = GetY();
	Direction olddir= direc();
	if (getCharIfAny(ch))
	{
		switch(ch)
		{
		case ARROW_LEFT:
			changedir(WEST);
			newx--;
			break;
		case ARROW_RIGHT:
			changedir(EAST);
			newx++;
			break;
		case ARROW_UP:
			changedir(NORTH);
			newy--;
			break;
		case ARROW_DOWN:
			changedir(SOUTH);
			newy++;
			break;
		default:
			break;
		}
	}
	else
	{
		switch(direc())
		{
		case WEST:
			newx--;
			break;
		case EAST:
			newx++;
			break;
		case NORTH:
			newy--;
			break;
		case SOUTH:
			newy++;
			break;
		default:
			break;
		}
	}
	
	// move NachMan
	if (direc() != NONE && Worldptr()->GetMaze()->GetGridContents(newx, newy) != WALL
			&& Worldptr()->GetMaze()->GetGridContents(newx, newy) != CAGEDOOR)
	{
		SetX(newx);
		SetY(newy);
	}
	else if (Worldptr()->GetMaze()->GetGridContents(newx, newy) == WALL
			|| Worldptr()->GetMaze()->GetGridContents(newx, newy) == CAGEDOOR)
	{
		changedir(olddir);
		switch(direc())
		{
		case NORTH:
			if (Worldptr()->GetMaze()->GetGridContents(GetX(), GetY()-1) != WALL
				&& Worldptr()->GetMaze()->GetGridContents(GetX(), GetY()-1) != CAGEDOOR)
				SetY(GetY()-1);
			break;
		case SOUTH:
			if (Worldptr()->GetMaze()->GetGridContents(GetX(), GetY()+1) != WALL
				&& Worldptr()->GetMaze()->GetGridContents(GetX(), GetY()+1) != CAGEDOOR)
				SetY(GetY()+1);
			break;
		case EAST:
			if (Worldptr()->GetMaze()->GetGridContents(GetX()+1, GetY()) != WALL
				&& Worldptr()->GetMaze()->GetGridContents(GetX()+1, GetY()) != CAGEDOOR)
				SetX(GetX()+1);
			break;
		case WEST:
			if (Worldptr()->GetMaze()->GetGridContents(GetX()-1, GetY()) != WALL
				&& Worldptr()->GetMaze()->GetGridContents(GetX()-1, GetY()) != CAGEDOOR)
				SetX(GetX()-1);
			break;
		default:
			break;
		}
	}
	
	// check for pellets eaten

	if (Worldptr()->GetMaze()->GetGridContents(GetX(), GetY()) == PELLET)
	{
		mscore += 10;
		Worldptr()->GetMaze()->SetGridContents(GetX(), GetY(), EMPTY);
		SoundFX::playNachManSound(PAC_SOUND_SMALL_EAT);
	}
	else if (Worldptr()->GetMaze()->GetGridContents(GetX(), GetY()) == POWERPELLET)
	{
		mscore += 100;
		Worldptr()->GetMaze()->SetGridContents(GetX(), GetY(), EMPTY);
		SoundFX::playNachManSound(PAC_SOUND_BIG_EAT);
		for (int j = 0; j < 4; j++)
		{
			if (Worldptr()->GetMonster(j)->Mstate() != RETURNTOHOME
				&& Worldptr()->GetMonster(j)->Mstate() != MONSTERDIE)
			{
				Worldptr()->GetMonster(j)->changeMstate(VULNERABLE);
				Worldptr()->GetMonster(j)->ChangeColor(LIGHTBLUE);
				if (Worldptr()->GetLevel() <= 8)
				{
					Worldptr()->GetMonster(j)->setvticks(100- (Worldptr()->GetLevel() * 10));
				}
				else
					Worldptr()->GetMonster(j)->setvticks(20);
					
			}
		}
	}

	// detect if NachMan ran into a monster

	for (int k = 0; k < 4; k++)
	{
		if (GetX() == Worldptr()->GetMonster(k)->GetX() &&
			GetY() == Worldptr()->GetMonster(k)->GetY())
		{
			if (Worldptr()->GetMonster(k)->Mstate() == VULNERABLE)
			{
				ChangeScore(1000);
				Worldptr()->GetMonster(k)->changeMstate(MONSTERDIE);
			}
			else if (Worldptr()->GetMonster(k)->Mstate() == NORMAL)
			{
				changeNMstate(true);
			}
		}
	}
}

/////////////////////////////////////
// Monster class functions
/////////////////////////////////////

//-------------
// Monster Constructors
//-------------
Monster::Monster(World* wptr, int x, int y, int m_id, colors Mcolor)
	: Actor(y, x, Mcolor, m_id, wptr),
	 vticks(0), lastdir(NONE), targetCx(0), targetCy(0),
	 state(NORMAL), normalcolor(Mcolor)
{}

Inky::Inky(World* wptr, int x, int y)
	: Monster(wptr, x, y, ITEM_MONSTER1, LIGHTRED),
	  decideticks(0), chase(true)
{}

Stinky::Stinky(World* wptr, int x, int y)
	: Monster(wptr, x, y, ITEM_MONSTER2, LIGHTGREEN)
{}

Dinky::Dinky(World* wptr, int x, int y)
	: Monster(wptr, x, y, ITEM_MONSTER3, LIGHTMAGENTA)
{}

Clyde::Clyde(World* wptr, int x, int y)
	: Monster(wptr, x, y, ITEM_MONSTER4, LIGHTCYAN)
{}

//-------------
// Monster Destructors
//-------------
Monster::~Monster()
{}

Inky::~Inky()
{}

Stinky::~Stinky()
{}

Dinky::~Dinky()
{}

Clyde::~Clyde()
{}

//-------------
// Monster Functions
//-------------

MonState Monster::Mstate()
{
	return state;
}

void Monster::changeMstate(MonState m)
{
	state = m;
	if (m == NORMAL)
		ChangeColor(NormalColor());
	else if (m == VULNERABLE)
		ChangeColor(LIGHTBLUE);
	else if (m == RETURNTOHOME)
		ChangeColor(LIGHTGRAY);
}

void Monster::randomtarget()
{
	int rx = (rand() % MAZE_WIDTH);
	int ry = (rand() % MAZE_HEIGHT);
	setTx(rx);
	setTy(ry);
}

void Monster::vulnerable()
{
	if (getMyID() != ITEM_MONSTER4)	// if not Clyde
		randomtarget();
	
	MonsterMove();
	
	// check if on same square as Nachman
	if (GetX() ==  Worldptr()->GetNachMan()->GetX() &&
		GetY() == Worldptr()->GetNachMan()->GetY() &&
		Mstate() == VULNERABLE)
	{
		Worldptr()->GetNachMan()->ChangeScore(1000);
		changeMstate(MONSTERDIE);
	}

	vticks--;

	// if vticks = 0 and not on Nachman, change to NORMAL
	// if vticks = 0 and on Nachman, change to MONSTERDIE
	if (vticks == 0 && Mstate() != MONSTERDIE)
	{
		changeMstate(NORMAL);
		ChangeColor(NormalColor());
	}
}

void Monster::monsterdie()
{
	SoundFX::playNachManSound(PAC_SOUND_BIG_EAT);
	ChangeColor(LIGHTGRAY);
	state = RETURNTOHOME;
}

void Monster::returntohome()
{
	int nextX = GetX();
	int nextY = GetY();
	if (!Worldptr()->GetMaze()->GetNextCoordinate(GetX(), GetY(), nextX, nextY))
	{
		state = NORMAL;
		ChangeColor(NormalColor());
		normal();
	}
	else
	{
		SetX(nextX);
		SetY(nextY);
	}
}

int Monster::targetX() const
{ return targetCx; }

int Monster::targetY() const
{ return targetCy; }

void Monster::setTx(int x)
{ targetCx = x; }

void Monster::setTy(int y)
{ targetCy = y; }

void Monster::setvticks(int n)
{ vticks = n; }

colors Monster::NormalColor()
{ return normalcolor; }

//-------------

void Monster::DoSomething()
{
	switch(state)
	{
	case NORMAL:
		normal();
		break;
	case VULNERABLE:
		vulnerable();
		break;
	case MONSTERDIE:
		monsterdie();
		break;
	case RETURNTOHOME:
		returntohome();
		break;
	}
}


void Monster::MonsterMove()
{
	if (Mstate() == NORMAL || Mstate() == VULNERABLE)
	{
		int oldx = GetX();
		int oldy = GetY();

		if (targetX() != GetX())
		{
			if (targetX() < GetX() && lastdir != EAST && GetX()-1 >= 0 &&		// move WEST
				Worldptr()->GetMaze()->GetGridContents(GetX()-1, GetY()) != WALL)
			{
				SetX(oldx-1);
				lastdir = WEST;
			}
			else if (targetX() > GetX() && lastdir != WEST && GetX()+1 < MAZE_WIDTH &&		// move EAST
				Worldptr()->GetMaze()->GetGridContents(GetX()+1, GetY()) != WALL)
			{
				SetX(oldx+1);
				lastdir = EAST;
			}
		}
		if (GetX() == oldx)	// monster didn't move left or right
		{
			if (targetY() != GetY())
			{
				if (targetY() < GetY() && lastdir != SOUTH && GetY()-1 >= 0 &&		// move NORTH
					Worldptr()->GetMaze()->GetGridContents(GetX(), GetY()-1) != WALL)
				{
					SetY(oldy-1);
					lastdir = NORTH;
				}
				else if (targetY() > GetY() && lastdir != NORTH && GetY()+1 < MAZE_HEIGHT &&		// move SOUTH
					Worldptr()->GetMaze()->GetGridContents(GetX(), GetY()+1) != WALL)
				{
					SetY(oldy+1);
					lastdir = SOUTH;
				}
			}
		}
		if (GetX() == oldx && GetY() == oldy)	// monster didn't move, pick random direction
		{
			int D = rand() % 4;
			for (int i = 0; i < 4; i++)
			{
				if (D == 0 && lastdir != SOUTH && GetY()-1 >= 0 &&	// choose NORTH
					Worldptr()->GetMaze()->GetGridContents(GetX(), GetY()-1) != WALL)
				{
					SetY(oldy-1);
					lastdir = NORTH;
					break;
				}
				else if (D == 1 && lastdir != NORTH && GetY()+1 < MAZE_HEIGHT &&	// choose SOUTH
					Worldptr()->GetMaze()->GetGridContents(GetX(), GetY()+1) != WALL)
				{
					SetY(oldy+1);
					lastdir = SOUTH;
					break;
				}
				else if (D == 2 && lastdir != WEST && GetX()+1 < MAZE_WIDTH &&	// choose EAST
					Worldptr()->GetMaze()->GetGridContents(GetX()+1, GetY()) != WALL)
				{
					SetX(oldx+1);
					lastdir = EAST;
					break;
				}
				else if (D == 3 && lastdir != EAST && GetX()-1 >= 0 &&	// choose WEST
					Worldptr()->GetMaze()->GetGridContents(GetX()-1, GetY()) != WALL)
				{
					SetX(oldx-1);
					lastdir = WEST;
					break;
				}
				if (D == 3)
					D = 0;
				else
					D++;
			}
		}
		if (GetX() == oldx && GetY() == oldy)	// monster didn't move
		{
			if (lastdir == NORTH)
			{
				SetY(GetY()+1);
				lastdir = SOUTH;
			}
			else if (lastdir == SOUTH)
			{
				SetY(GetY()-1);
				lastdir = NORTH;
			}
			else if (lastdir == EAST)
			{
				SetX(GetX()-1);
				lastdir = WEST;
			}
			else if (lastdir == WEST)
			{
				SetX(GetX()+1);
				lastdir = EAST;
			}
		}
	}
}

//-------------
// Individual Monster Functions:
//-------------

//-------------
// Inky Functions
//-------------

void Inky::changeMstate(MonState m)
{
	Monster::changeMstate(m);
	if (Mstate() == NORMAL)
		decideticks = 0;
}

void Inky::normal()
{
	if (decideticks == 0)
	{
		decideticks = 10;
		int V = rand() % 100;
		if (0 <= V < 80)
			chase = true;
		else if (80 <= V < 100)
			chase = false;
	}
	if (chase && decideticks != 0)
	{
		setTx(Worldptr()->GetNachMan()->GetX());
		setTy(Worldptr()->GetNachMan()->GetY());
	}
	else if (!chase)
	{
		randomtarget();
	}

	MonsterMove();
	if (GetX() == Worldptr()->GetNachMan()->GetX() &&
		GetY() == Worldptr()->GetNachMan()->GetY())
		Worldptr()->GetNachMan()->changeNMstate(true);

	decideticks--;
}

//-------------
// Stinky Functions
//-------------

void Stinky::normal()
{
	if (abs(GetX() - Worldptr()->GetNachMan()->GetX()) <= 5 &&
		abs(GetY() - Worldptr()->GetNachMan()->GetY()) <= 5)
	{
		setTx(Worldptr()->GetNachMan()->GetX());
		setTy(Worldptr()->GetNachMan()->GetY());
	}
	else
		randomtarget();

	MonsterMove();
	if (GetX() == Worldptr()->GetNachMan()->GetX() &&
		GetY() == Worldptr()->GetNachMan()->GetY())
		Worldptr()->GetNachMan()->changeNMstate(true);
}

//-------------
// Dinky Functions
//-------------

void Dinky::normal()
{
	if (GetX() == Worldptr()->GetNachMan()->GetX())	// same column, vertical line of sight
	{
		int i = 0;
		if (GetY() < Worldptr()->GetNachMan()->GetY())
		{
			for (i = GetY()+1; i < Worldptr()->GetNachMan()->GetY(); i++)
				if (Worldptr()->GetMaze()->GetGridContents(i, GetX()) == WALL)
					break;
		}
		else if (GetY() > Worldptr()->GetNachMan()->GetY())
		{
			for (i = GetY()-1; i > Worldptr()->GetNachMan()->GetY(); i--)
				if (Worldptr()->GetMaze()->GetGridContents(i, GetX()) == WALL)
					break;
		}
		if (i == Worldptr()->GetNachMan()->GetY())	// Dinky is in vertical line of sight of NachMan, no walls in between
		{
			setTy(i);
			setTx(Worldptr()->GetNachMan()->GetX());
		}
	}
	else if (GetY() == Worldptr()->GetNachMan()->GetY())	// same row, horizontal line of sight
	{
		int i = 0;
		if (GetX() < Worldptr()->GetNachMan()->GetX())
		{
			for (i = GetX()+1; i < Worldptr()->GetNachMan()->GetX(); i++)
				if (Worldptr()->GetMaze()->GetGridContents(GetY(), i) == WALL)
					break;
		}
		else if (GetY() > Worldptr()->GetNachMan()->GetY())
		{
			for (i = GetX()-1; i > Worldptr()->GetNachMan()->GetX(); i--)
				if (Worldptr()->GetMaze()->GetGridContents(GetY(), i) == WALL)
					break;
		}
		if (i == Worldptr()->GetNachMan()->GetX())	// Dinky is in vertical line of sight of NachMan, no walls in between
		{
			setTx(i);
			setTy(Worldptr()->GetNachMan()->GetY());
		}
	}
	else
		randomtarget();

	MonsterMove();
	
	if (GetX() == Worldptr()->GetNachMan()->GetX() &&
		GetY() == Worldptr()->GetNachMan()->GetY())
		Worldptr()->GetNachMan()->changeNMstate(true);
}

//-------------
// Clyde Functions
//-------------

void Clyde::normal()
{
	randomtarget();
	MonsterMove();
	if (GetX() == Worldptr()->GetNachMan()->GetX() &&
		GetY() == Worldptr()->GetNachMan()->GetY())
		Worldptr()->GetNachMan()->changeNMstate(true);
}

void Clyde::vulnerable()
{
	// NachMan in upper left of grid, set target lower right
	if (Worldptr()->GetNachMan()->GetX() <= MAZE_WIDTH/2
		&& Worldptr()->GetNachMan()->GetY() <= MAZE_HEIGHT/2)
	{
		setTx(MAZE_WIDTH-1);
		setTy(MAZE_HEIGHT-1);
	}
	// NachMan in upper right of grid, set target lower left
	else if (Worldptr()->GetNachMan()->GetX() > MAZE_WIDTH/2
		&& Worldptr()->GetNachMan()->GetY() <= MAZE_HEIGHT/2)
	{
		setTx(0);
		setTy(MAZE_HEIGHT-1);
	}
	// NachMan in lower left of grid, set target upper right
	else if (Worldptr()->GetNachMan()->GetX() <= MAZE_WIDTH/2
		&& Worldptr()->GetNachMan()->GetY() > MAZE_HEIGHT/2)
	{
		setTx(MAZE_WIDTH-1);
		setTy(0);
	}
	// NachMan in lower right of grid, set target upper left
	else if (Worldptr()->GetNachMan()->GetX() > MAZE_WIDTH/2
		&& Worldptr()->GetNachMan()->GetY() > MAZE_HEIGHT/2)
	{
		setTx(0);
		setTy(0);
	}

	Monster::vulnerable();
}