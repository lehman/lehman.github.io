#ifndef _ACTOR_H_
#define _ACTOR_H_

#include "testdefines.h"
#include "GraphManager.h"
class World;
class Maze;
#include <iostream>
using namespace std;

class Actor
{
public:
	Actor(int y, int x, colors color, int id, World* wptr);
	virtual ~Actor();
	int GetX() const;
	int GetY() const;
	void SetX(int newXCoord);
	void SetY(int newYCoord);
	virtual void DoSomething() = 0;
	colors GetDisplayColor() const;
	void ChangeColor(colors c);
	int getMyID() const;
	Direction direc() const;
	void changedir(Direction d);
	World* Worldptr() const;
private:
	int mx;
	int my;
	colors mcolor;
	int mid;
	Direction dir;
	World* mWptr;
};

class NachMan : public Actor
{
public:
	NachMan(World* wptr, int y, int x);
	virtual ~NachMan();
	int GetNumLivesLeft() const;
	void DecrementNumLives();
	int GetScore() const;
	void ChangeScore(int s);
	virtual void DoSomething();
	bool NMstate() const;
	void changeNMstate(bool st);
private:
	int mscore;
	int mlives;
	bool mstate;	// true if dead
};

enum MonState {
	VULNERABLE, NORMAL, MONSTERDIE, RETURNTOHOME
};

class Monster : public Actor
{
public:
	Monster(World* wptr, int x, int y, int m_id, colors Mcolor);
	virtual ~Monster();
	void DoSomething();
	void MonsterMove();
	virtual void normal() = 0;
	virtual void vulnerable();
	void monsterdie();
	void returntohome();
	void randomtarget();
	int targetX() const;
	int targetY() const;
	void setTx(int x);
	void setTy(int y);
	MonState Mstate();
	virtual void changeMstate(MonState m);
	void setvticks(int n);
	colors NormalColor();
private:
	MonState state;
	int vticks;
	Direction lastdir;
	int targetCx;
	int targetCy;
	colors normalcolor;
};

class Inky : public Monster
{
public:
	Inky(World* wptr, int x, int y);
	~Inky();
	virtual void normal();
	virtual void changeMstate(MonState m);
private:
	int decideticks;
	bool chase;
};

class Stinky : public Monster
{
public:
	Stinky(World* wptr, int x, int y);
	~Stinky();
	virtual void normal();
private:
};

class Dinky : public Monster
{
public:
	Dinky(World* wptr, int x, int y);
	~Dinky();
	virtual void normal();
private:
};

class Clyde : public Monster
{
public:
	Clyde(World* wptr, int x, int y);
	~Clyde();
	virtual void normal();
	virtual void vulnerable();
private:
};

#endif // #ifndef _ACTOR_H_
